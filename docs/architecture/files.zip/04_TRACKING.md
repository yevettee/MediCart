# MISSION 4 — Tracking (피규어 추종)

**담당:** (tracking 담당자)
**주 패키지:** `nurse_tracker/` → **`medicine_tracker`로 이름 변경 권장** (`tracker_node.py`)
**연계:** MISSION 5(robot6 mission_manager 상태기), Nav2

> 먼저 `00_INTEGRATION_GUIDE.md`를 읽고 오세요.

---

## 1. 무엇을 만드나 (한 줄)

robot6이 **약품실에서 나와 환자 침대로 갈 때**, RC카에 장착된 **인형 피규어를 YOLO로 "사람"으로 감지**하고, **일정 거리를 유지하며 따라가게** 하는 노드입니다. 즉 이 구간은 자율주행(Nav2 목적지 이동)이 아니라 **동적 타겟 추종**입니다.

### ★ 중요: 이 기능은 두 설계 문서에서 빠져 있었습니다 ★

`05_multi_robot_system_architecture.md`와 `06_..._explanation_script.md` 모두 이 구간을 **Nav2 자율주행으로 잘못 가정**하고 있고, tracking은 "추후 범위"로만 적혀 있습니다(05 문서 326·444·605번 줄). 실제 요구사항은 추종이므로, 문서도 수정이 필요합니다(이 미션 9번 참고). 헷갈리면 이 미션 문서 기준으로 진행하세요.

---

## 2. 제어 방식 결정 사항 (확정됨)

**`/robot6/target_pose` 발행 → Nav2가 그 pose로 추종** 방식으로 갑니다. (기존 문서의 `/robot6/target_pose` 가정과 일치, 05 문서 444번 줄)

```
카메라 → YOLO로 피규어 감지 → 피규어까지 거리/방향 계산
       → "일정 거리 뒤" 목표 지점을 PoseStamped로 변환
       → /robot6/target_pose 발행 → Nav2가 따라감
```

> tracker_node는 **"어디로 갈지(target_pose)"만 계속 갱신**하고, 실제 주행은 Nav2가 합니다. cmd_vel을 직접 쏘지 않으므로 Nav2의 장애물 회피·경로계획을 그대로 활용할 수 있는 게 장점입니다.

---

## 3. 구현해야 할 기능

### 3-1. YOLO 피규어 감지
- 입력: `/robot6/oakd/image_raw` (RGB) + depth (거리 측정용)
- 피규어를 **person 클래스로 감지**(YOLO 기본 person 클래스 활용, 또는 피규어 커스텀 학습).
- 출력: bounding box + confidence + depth(피규어까지 거리). → `TargetBBox` 메시지에 담김(아래 4번).

### 3-2. 추종 목표 계산
- depth로 **피규어까지 현재 거리** 측정.
- 목표: "피규어 뒤 N미터"(예: 0.8m) 유지. 너무 가까우면 정지, 너무 멀면 추종.
- bbox 중심의 좌우 위치 → 회전 방향 결정.
- 이를 map 또는 base_link 기준 `PoseStamped`로 변환해 `/robot6/target_pose` 발행.

### 3-3. 타겟 분실 처리
- 피규어가 화면에서 사라지면(가림/이탈) → 마지막 위치에서 정지하거나 잠시 대기. 함부로 직진 금지.

### 3-4. ★ 장애물 회피 — 아래 중 하나 선택 ★

미션 시작 전에 팀과 난이도 보고 고르세요. (난이도 순)

| 옵션 | 내용 | 난이도 | 권장 상황 |
| --- | --- | --- | --- |
| A. 거리유지만 | 피규어만 따라감, 회피 무시 | 낮음 | 데모 시간 촉박할 때, 복도가 단순할 때 |
| B. LiDAR 간단 정지/회피 | 앞에 장애물 뜨면 멈추거나 살짝 우회 | 중간 | 사람/물체 끼어들 수 있을 때 |
| C. Nav2 costmap 연동 | target_pose를 Nav2가 회피하며 추종 | 높음(but 거의 공짜) | **target_pose 방식이면 사실상 이게 자연스러움** |

> **참고:** target_pose → Nav2 방식을 택했으므로, **C가 의외로 쉽습니다.** Nav2가 이미 costmap으로 회피하기 때문에, target_pose만 잘 던지면 회피는 Nav2가 알아서 해줍니다. 다만 동적 타겟이라 Nav2 목표를 자주 갱신하면 경로 재계획이 출렁일 수 있으니, **발행 주기(예: 2~5Hz)와 목표 변화 임계값**을 튜닝하세요. 시간 없으면 A로 시작 → C로 확장 권장.

---

## 4. 데이터 형식

```
# 감지 결과 (medi_interfaces에 이미 정의됨 — TargetBBox)
TargetBBox:
  Header header
  float32[4] bbox            # x1, y1, x2, y2
  float32 confidence
  int32 tracking_id          # 여러 후보 중 추적 대상 id
  float32 depth              # 피규어까지 거리(m)
  geometry_msgs/Point spatial_coordinates

# 추종 목표 (Nav2로)
geometry_msgs/PoseStamped    # /robot6/target_pose
```

---

## 5. ROS2 통신

| 인터페이스 | 타입 | 방향 | 상대 |
| --- | --- | --- | --- |
| `/robot6/oakd/image_raw` | `sensor_msgs/Image` | **sub** | 카메라 (피규어 감지) |
| `/robot6/oakd/depth_image` 또는 depth | `sensor_msgs/Image` | **sub** | 거리 측정 |
| `/robot6/target_pose` | `geometry_msgs/PoseStamped` | **pub** | Nav2 (추종 목표) |
| `/robot6/tracked_target` (선택) | `TargetBBox` | **pub** | 디버그/대시보드 시각화 |

> Nav2가 `/robot6/target_pose`를 어떤 방식으로 따라가게 할지(NavigateToPose를 계속 재호출 vs follow behavior)는 **M5(mission_manager)와 협의** 필요. mission_manager의 상태기에서 `FOLLOW` 상태일 때만 추종이 활성화되어야 합니다(아래 6번).

---

## 6. mission_manager와의 연동 (M5와 협의)

robot6 상태기에 **추종 구간**을 명시해야 합니다. 기존 문서의 상태기는:
```
IDLE → UNDOCK → MOVE_TO_PHARMACY → LOAD_MEDICINE → MOVE_TO_PATIENT_ROOM → SCAN → RETURN → DOCK
```
여기서 `MOVE_TO_PATIENT_ROOM`을 **`FOLLOW_TO_PATIENT_ROOM`(추종)**으로 바꾸거나 분기 추가가 필요합니다. 즉:
```
... → LOAD_MEDICINE → FOLLOW_TO_PATIENT_ROOM(tracking) → SCAN → ...
```
- mission_manager가 "지금부터 추종" 신호를 줄 때 tracker_node가 활성화되고, 침대 도착(또는 추종 종료 조건)에서 비활성화.
- 활성/비활성을 어떻게 신호할지(파라미터? 별도 서비스? 상태 토픽 구독?) M5와 정하세요. 가장 간단: tracker가 `/robot6/robot_state` 구독해서 `FOLLOW`일 때만 발행.

---

## 7. DB와의 상호작용

**없음.** 추종은 순수 인식·제어 기능이라 DB를 거치지 않습니다. (투약 세션 기록은 mission_manager/db_node가 담당)

---

## 8. 단위 테스트 (로봇·DB 없이도 단계적으로)

```bash
# 1. YOLO 감지만: 웹캠/녹화 영상으로 피규어 박스 뜨는지
python3 tracker_test.py   # bbox, depth 출력 확인

# 2. target_pose 발행 확인
ros2 run medicine_tracker tracker_node
ros2 topic echo /robot6/target_pose

# 3. RC카로 실제 추종: 피규어를 좌우/앞뒤로 움직이며 거리 유지 확인
```

- **거리 유지 파라미터**(목표 거리, 정지 임계, 발행 주기)는 launch 파라미터로 빼서 현장 튜닝하기 쉽게.
- RC카 속도가 로봇 최대 속도보다 빠르면 놓치니, 데모 시 RC카를 천천히.

---

## 9. ★ 설계 문서 수정 제안 (지금 바로 고치진 말 것) ★

이 기능이 문서에 빠져있으니, 통합 시 아래를 반영해야 합니다. (제가 돌아와서 같이 정리해도 됨)

**05_multi_robot_system_architecture.md:**
1. `5.6` 뒤에 **`5.6b TrackerNode for /robot6`** 신설 — 위 5번 통신 표를 계약으로 추가.
2. `5.5` robot6 상태기: `MOVE_TO_PATIENT_ROOM` → `FOLLOW_TO_PATIENT_ROOM` 교체, 605번 줄 "FOLLOW는 추후 확장" → "현재 구현 대상"으로 정정.
3. `6.` 데이터모델 `TargetBBox`: "future nurse tracking" → "robot6 medicine delivery tracking (current)".
4. Architecture Decisions(444번 줄): "Nurse following 범위 제외" → "Medication delivery following 범위 포함".

**06 문서:** `13.2`/`13.3` robot6 흐름 4번 스텝(환자 병실 이동)을 Nav2 → tracking으로 교체.

---

## 10. 완료 기준 (Definition of Done)

- [ ] YOLO로 피규어를 person으로 안정 감지 (bbox + depth)
- [ ] 일정 거리 유지하며 `/robot6/target_pose` 발행
- [ ] 타겟 분실 시 안전 처리(정지/대기)
- [ ] 장애물 회피 옵션(A/B/C 중 택1) 구현
- [ ] mission_manager 상태기 FOLLOW 구간과 연동(M5 협의)
- [ ] RC카로 실제 추종 데모 성공
- [ ] (패키지명 변경 시) `nurse_tracker`→`medicine_tracker` 반영
- [ ] 본인 브랜치 → PR (main 직접 push 금지)
