# MISSION 5 — robot3 환자 순회 (2명 전담)

**담당:** (robot3 전담 2명)
**주 패키지:** `mission_manager/` + `patient_identifier/identifier_node.py`
**연계:** MISSION 1(QR), MISSION 3(DB)

> 먼저 `00_INTEGRATION_GUIDE.md`를 읽고 오세요. 두 분이 담당이니, 아래 8번에서 **역할 분담**을 먼저 정하세요.

---

## 1. 무엇을 만드나 (한 줄)

robot3가 **충전기에서 나와 → 병실들을 순회 → 각 방에서 환자 감지+QR+DB검증 → 결과 기록 → 복귀+도킹**까지 자동으로 도는 **환자 순회 end-to-end**를 완성합니다. robot3의 "두뇌(mission_manager)"와 "눈(identifier)"을 모두 책임집니다.

---

## 2. 구현해야 할 기능 — 크게 두 덩어리

### A. mission_manager (순회 두뇌)
현재 `mission_manager_node`는 상태기 뼈대와 `/robot6/start_patrol` 서버만 있음. **Nav2/Create3/DB 연결이 전부 비어있음.** 아래를 구현:

- **상태기 구동**: `IDLE → UNDOCK → PATROL → IDENTIFY → INTERVIEW → NEXT_ROOM → (PATROL|RETURN) → DOCK → IDLE` (05 문서 532번 줄)
- **service server**: `/robot3/start_patrol`(StartPatrol), `/robot3/move_home`(MoveHome), `/robot3/cancel_mission`(Trigger)
- **action client**: `/robot3/navigate_to_pose`(Nav2), `/robot3/undock`·`/robot3/dock`(Create3)
- **topic**: `/robot3/patient_identified` 구독(결과 받기), `/robot3/robot_state` 발행(상태 알림), `/robot3/emergency_stop` 구독
- **DB service client**: `/medicart/db/update_visit_status`(방문결과 기록), 필요시 `/medicart/db/get_prescription`
- **waypoint**: 순회할 병실 좌표를 RTDB `/rooms`(type=bed) 또는 `medi_bringup/config/patrol_waypoints.yaml`에서 로드. ★ room pose 조회 srv가 아직 없으니(M3 참고), **당장은 YAML 사용 권장**.

### B. identifier_node (순회 눈)
현재 `/robot6/...`로 하드코딩되어 robot3에서 못 씀. **namespace 정리 + QR 모듈(M1) 통합:**

- 카메라 구독: `/robot3/oakd/image_raw`, `/robot3/oakd/depth_image` (현재 `/robot6` → 수정)
- 결과 발행: `/robot3/patient_identified` (현재 `/robot6` → 수정)
- DB client: `/medicart/db/get_prescription` (현재 `/robot6/db/get_prescription` → 수정)
- 파이프라인(05 문서 564번 줄): `PersonDetector.detect()` → `QrScanner.scan()`(M1) → `PatientValidator.validate()` → `_publish(PatientIdentified)`

---

## 3. ★ 최우선: /robot6 하드코딩 제거 ★

이건 robot3 동작의 전제조건이자, 통합 가이드 0.5의 공통 선행작업입니다. 현재 하드코딩 위치(05 문서 358번 줄):

| 파일 | 현재 하드코딩 | 고칠 방향 |
| --- | --- | --- |
| `mission_manager_node.py` | `START_PATROL_SERVICE = '/robot6/start_patrol'` | namespace 주입 + 상대 이름 |
| `identifier_node.py` | `/robot6/oakd/image_raw` 등 | 상대 토픽명 `oakd/image_raw` |
| `patient_validator.py` | `/robot6/db/get_prescription` | 공용 `/medicart/db/get_prescription` |

**권장 방식(05 문서 372번 줄):** launch에서 namespace를 `/robot3`로 주입하고, **코드에서는 상대 이름**(`oakd/image_raw`)을 쓰기. 그러면 같은 코드로 robot3/robot6 둘 다 띄울 수 있어 유지보수가 쉬움. → `medi_bringup/launch/robot3_patrol.launch.py` 작성.

> ★ launch 파일과 medi_interfaces는 공용 영역입니다. 수정 시 단톡방 공유(통합 가이드 0.4).

---

## 4. 환자 식별 status 5종 (정확히 지킬 것)

identifier가 발행하고 mission_manager가 받아서 처리 + DB 기록하는 결과값:

| status | 뜻 | mission_manager 처리 |
| --- | --- | --- |
| `identified` | 사람 있음 + QR/DB 방 일치 | 방문 성공 기록, 다음 방 |
| `absent` | 사람 미감지 | 부재 기록, 재방문 큐 후보 |
| `no_qr` | 사람 있는데 QR 못 읽음 | 알림, 수동 확인 |
| `mismatch` | QR 환자 ≠ 현재 방 | 알림, DB/환자 확인 |
| `db_error` | DB 조회 실패 | 시스템 오류 알림 |

검증 로직(05 문서 568번 줄): QR의 patient_id → `get_prescription`으로 환자 room 조회 → **현재 순회 중인 방과 비교** → 같으면 identified, 다르면 mismatch.

---

## 5. ROS2 통신 (mission_manager 기준)

| 인터페이스 | 타입 | 방향 | 상대 |
| --- | --- | --- | --- |
| `/robot3/start_patrol` | `StartPatrol` | server | dashboard |
| `/robot3/move_home` | `MoveHome` | server | dashboard |
| `/robot3/cancel_mission` | `std_srvs/Trigger` | server | dashboard |
| `/robot3/patient_identified` | `PatientIdentified` | **sub** | identifier_node |
| `/robot3/robot_state` | `RobotState` | **pub** | dashboard |
| `/robot3/emergency_stop` | `std_msgs/Bool` | sub | dashboard |
| `/robot3/navigate_to_pose` | `nav2_msgs/NavigateToPose` | action client | Nav2 |
| `/robot3/undock`, `/robot3/dock` | `irobot_create_msgs/action/*` | action client | Create3 |
| `/medicart/db/update_visit_status` | `UpdateVisitStatus` | service client | db_node(M3) |
| `/medicart/db/get_prescription` | `GetPrescription` | service client | db_node(M3) |

---

## 6. DB와의 상호작용

**직접 RTDB 안 만짐. db_node service만 호출.**
- 환자 검증: identifier의 PatientValidator → `/medicart/db/get_prescription`(M3)
- 방문 기록: mission_manager → `/medicart/db/update_visit_status`(M3) → RTDB `/robot_visits`, `/patients/{id}/visits`에 기록됨

> M3가 아직 실제 RTDB 연결 전이면, M3에게 **더미 응답 server**라도 먼저 띄워달라고 요청(통합 가이드 0.6). 그동안 robot3는 Nav2 이동·상태기 로직을 먼저 완성.

---

## 7. 순회 전체 흐름 (통신 단위, 06 문서 12.3)

| 순서 | 누가 | 무엇 | 받는 쪽 |
| --- | --- | --- | --- |
| 1 | dashboard | `/robot3/start_patrol` | mission_manager |
| 2 | mission_manager | `/robot3/undock` action | Create3 |
| 3 | mission_manager | `/robot3/navigate_to_pose` action | Nav2 (병실로) |
| 4 | camera | `/robot3/oakd/image_raw` | identifier |
| 5 | identifier | `/medicart/db/get_prescription` | db_node |
| 6 | identifier | `/robot3/patient_identified` | mission_manager, dashboard |
| 7 | mission_manager | `/medicart/db/update_visit_status` | db_node |
| 8 | mission_manager | `/robot3/robot_state` | dashboard |
| 9 | mission_manager | `/robot3/dock` action | Create3 |

(3~7을 병실 수만큼 반복 → 다 돌면 home 복귀 → dock)

---

## 8. ★ 2인 역할 분담 제안 ★

두 분이 같은 패키지를 동시에 만지면 충돌나니, 이렇게 나누길 권합니다:

| 분담 | 담당 파일 | 내용 |
| --- | --- | --- |
| **담당자 A** | `mission_manager/*` | 상태기, service server, Nav2/Create3 action client, robot_state 발행 |
| **담당자 B** | `patient_identifier/identifier_node.py` + `person_detector.py` | namespace 정리, 카메라 파이프라인, PersonDetector(YOLO), M1(QR)·M3(DB) 연결 |

- **경계 = `/robot3/patient_identified` 토픽.** A는 이걸 "구독"만, B는 "발행"만. 이 토픽 메시지 형식만 맞추면 서로 독립 개발 가능.
- 둘 다 `medi_bringup/launch`를 건드리니, launch는 한 명이 대표로 작성하고 공유.

---

## 9. 단위 테스트

```bash
# mission_manager: 식별결과 없이 상태 전이만 (B 없이 A 테스트)
ros2 run mission_manager mission_manager_node
ros2 service call /robot3/start_patrol medi_interfaces/srv/StartPatrol "{}"
ros2 topic echo /robot3/robot_state           # 상태 바뀌는지

# identifier: mission_manager 없이 결과 발행만 (A 없이 B 테스트)
ros2 run patient_identifier identifier_node
ros2 topic echo /robot3/patient_identified

# A가 B 없이 테스트: patient_identified를 수동 발행
ros2 topic pub /robot3/patient_identified medi_interfaces/msg/PatientIdentified \
  "{patient_id: 'P001', room: '101-A', is_identified: true, status: 'identified'}"
```

---

## 10. 완료 기준 (Definition of Done)

- [ ] `/robot6` 하드코딩 전부 제거, robot3 namespace로 동작
- [ ] mission_manager 상태기가 순회 한 바퀴 완주(undock→방들→dock)
- [ ] Nav2/Create3 action client 동작
- [ ] identifier가 5종 status 정확 발행 + mission_manager가 처리
- [ ] QR(M1)·DB(M3) 연결 완료
- [ ] `/robot3/robot_state` 발행되어 dashboard에서 보임
- [ ] robot3_patrol.launch.py 작성
- [ ] 본인 브랜치 → PR (main 직접 push, force-push 금지)
