# MISSION 2 — 약품실 꾸미기 및 OCR

**담당:** (OCR/약품실 담당자)
**주 패키지:** `ocr_detector/` (`ocr_node.py`, `ocr_engine.py`, `text_cleaner.py`)
**연계:** MISSION 3(DB 검증), scanner_node(검증 오케스트레이션)

> 먼저 `00_INTEGRATION_GUIDE.md`를 읽고 오세요.

---

## 1. 무엇을 만드나 (한 줄)

robot6이 약 라벨을 카메라로 보면, **그 라벨에서 글자를 읽어(OCR) 텍스트로 반환하는** 노드입니다. + 데모가 잘 되도록 **약품실 촬영 환경을 세팅**합니다. "이 글자가 처방과 맞나?" 판단은 MISSION 3(DB)가 하고, OCR은 **글자를 잘 읽어내는 것**까지가 책임입니다.

---

## 2. 구현해야 할 기능

### 2-1. OCR 엔진 (`ocr_engine.py`)
- 입력: 약 라벨 이미지 (numpy array)
- 출력: 인식된 raw 텍스트 + confidence
- 엔진 후보: **EasyOCR**(한글+영문 강함, 설치 무거움) / **Tesseract**(가벼움, 한글 정확도 낮음) / PaddleOCR. 약 라벨이 한글이면 EasyOCR 권장.
- 현재 `recognize()`가 placeholder이므로 실제 엔진 연결 필요.

### 2-2. 텍스트 정리 (`text_cleaner.py`)
- OCR raw 결과는 지저분함(공백, 줄바꿈, 오인식 문자). 약명 비교가 쉽게 cleaned_text 생성.
- 예: 대소문자 통일, 특수문자 제거, 약명 키워드만 추출.

### 2-3. `GetOcrResult` service server (`ocr_node.py`)
- **이게 핵심 산출물.** scanner_node가 이 service를 호출하면, **최신 카메라 프레임을 OCR해서 결과를 응답**.
- 카메라 토픽을 계속 구독하다가, 호출 시점의 latest frame을 처리하는 구조.

---

## 3. ★ 약품실 꾸미기 (촬영 환경) ★

OCR 정확도는 환경이 8할입니다. 데모 성공을 위해:

1. **약 라벨 디자인 통일** — 글자 크고 또렷하게, 배경 단순하게. 손글씨 X, 인쇄체 O.
2. **조명** — 그림자/반사 최소화. 정면 균일 조명.
3. **카메라-라벨 거리/각도 고정** — robot6이 약품실/침대에서 멈췄을 때 라벨이 화면 중앙에 잘 잡히는 위치를 미리 잡아두기.
4. **약 종류** — 처방 검증을 테스트하려면 **최소 2~3종 약 라벨**이 필요(순서 검증 때문). MISSION 3의 `/prescriptions` medicines 배열과 **약명이 정확히 일치**해야 하니, 약명을 M3와 먼저 맞추세요.

> ★ M3와 합의 필요: 라벨에 적을 약명 = `/prescriptions/.../medicines/{n}/name` 과 동일해야 함. 안 그러면 OCR은 잘 돼도 검증이 항상 false.

---

## 4. 데이터 형식

```
GetOcrResult.srv
  # Request: (empty)
  ---
  # Response:
  bool success
  string raw_text       # OCR 원본 (예: "타이레놀  500mg\n2026-12")
  string cleaned_text   # 정리본 (예: "타이레놀 500mg")
  float32 confidence    # 0.0 ~ 1.0
  string message
```

(이 srv는 medi_interfaces에 **이미 존재** — 06 문서 350번 줄. server 구현만 하면 됨)

---

## 5. ROS2 통신

| 인터페이스 | 타입 | 방향 | 상대 |
| --- | --- | --- | --- |
| `/robot6/oakd/image_raw` 또는 `/robot6/webcam/image_raw` | `sensor_msgs/Image` | **sub** | 카메라 드라이버 |
| `/robot6/ocr/get_result` | `GetOcrResult` | **service server** | scanner_node가 호출 |
| `/ocr/latest` (선택) | RTDB write | (선택) | 디버그용 최신 OCR 결과. 굳이 안 해도 됨 |

> 카메라 토픽이 OAK-D인지 웹캠인지 robot6 하드웨어 구성에 따라 다름. 05 문서 621번 줄 참고. 어느 쪽인지 robot6 하드웨어 담당과 확인하세요.

---

## 6. DB와의 상호작용

**OCR 노드는 DB를 직접 안 만집니다.** 흐름은:

```
scanner_node → /robot6/ocr/get_result 호출 → (당신의 ocr_node가 글자 읽어서 cleaned_text 반환)
            → scanner_node가 그 텍스트를 /medicart/db/verify_medicine(M3)로 넘김
            → db_node가 /prescriptions의 현재 step 약과 대조 → match true/false
```

즉 OCR은 **텍스트만 정확히 넘기면 됨.** 대조는 DB(M3)가 합니다.

---

## 7. 단위 테스트 (로봇·DB 없이)

```bash
# 1. 엔진만 정지 이미지로
python3 -c "from ocr_detector.ocr_engine import OcrEngine; print(OcrEngine().recognize('label_sample.jpg'))"

# 2. service 떠 있는지 + 응답 확인
ros2 run ocr_detector ocr_node
ros2 service call /robot6/ocr/get_result medi_interfaces/srv/GetOcrResult "{}"
```

- 약 라벨 사진 여러 장(정상/흐릿/각도 틀어진 것) 준비해서 인식률 체크.
- confidence가 낮을 때 어떻게 할지(재시도? 그냥 반환?) 정책을 message에 담아두면 통합 때 편함.

---

## 8. 완료 기준 (Definition of Done)

- [ ] `ocr_engine.recognize()`가 실제 엔진으로 동작
- [ ] `GetOcrResult` service server가 최신 프레임을 OCR해 응답
- [ ] cleaned_text가 약명 비교에 바로 쓸 수 있게 정리됨
- [ ] 약 라벨 2~3종 제작 + 약명을 M3와 일치시킴
- [ ] 약품실/촬영 환경 세팅 완료
- [ ] 본인 브랜치 → PR (main 직접 push 금지)
