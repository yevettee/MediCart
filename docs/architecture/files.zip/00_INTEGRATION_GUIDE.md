# MISSION 0 — 통합 가이드 (모두 먼저 읽기)

> 내일 제가 자리에 없어서, 각자 구현이 어떻게 맞물려야 하는지 미리 정리해둡니다.
> **각자 자기 미션 파일을 보기 전에 이 문서를 먼저 읽어주세요.** 인터페이스 계약(이름/타입)만 서로 지키면, 따로 개발해도 나중에 한 번에 붙습니다.

---

## 0.1 오늘의 큰 그림

MediCart는 로봇 2대입니다.

- `/robot3` = 환자 순회 (사람 감지 → QR → DB 검증 → 방문기록)
- `/robot6` = 투약 (약품실 이동 → **피규어 추종(tracking)으로 침대 이동** → 약 라벨 OCR → 처방 검증)

DB는 로봇이 직접 만지지 않습니다. **무조건 `db_node`라는 ROS service를 통해서만** 읽고 씁니다. RTDB 구조가 바뀌어도 로봇 코드는 안 바뀌게 하려는 의도예요.

```
[사람] → dashboard → mission_manager(두뇌) → Nav2/Create3(다리)
                                          → identifier / ocr+scanner(눈)
                                          → db_node → Firebase RTDB(기록장)
```

---

## 0.2 누가 무엇을 담당하나 (6 미션)

| 미션 파일 | 태스크 | 핵심 산출물 | 주로 건드리는 패키지 |
| --- | --- | --- | --- |
| `01_QR.md` | QR 코드 인식 | QR payload 파싱 → patient_id/room 추출, identifier에 연결 | `patient_identifier/qr_scanner.py` |
| `02_OCR.md` | 약품실 꾸미기 + OCR | 약 라벨 글자 읽기, `GetOcrResult` server, 촬영 환경 세팅 | `ocr_detector/*` |
| `03_QR_DB.md` | QR ↔ DB | `db_node` RTDB 연결, `GetPrescription`/`VerifyMedicine`/`UpdateVisitStatus` server, 처방 스키마 | `db_bridge/*` + RTDB |
| `04_TRACKING.md` | tracking | YOLO로 피규어 감지 → `/robot6/target_pose` 발행 → Nav2 추종 | `nurse_tracker/*`(이름 변경 권장) |
| `05_ROBOT3.md` | robot3 (2명 전담) | 환자 순회 mission_manager + identifier 통합, end-to-end | `mission_manager/*`, `patient_identifier/*` |
| `00`(이 문서) | 통합 | 계약/순서/충돌 방지 | — |

---

## 0.3 절대 깨면 안 되는 인터페이스 계약 (이름·타입 고정)

아래 이름과 타입은 **서로 약속한 "벽"입니다.** 각자 자기 안쪽 구현은 자유지만, 이 경계의 이름/타입은 임의로 바꾸지 마세요. 바꿔야 하면 단톡방에 먼저 공유.

### Service (db_node가 제공 — MISSION 3 담당)

| 이름 | 타입 | Request | Response |
| --- | --- | --- | --- |
| `/medicart/db/get_prescription` | `GetPrescription` | `string patient_id` | `bool success`, `PatientInfo patient`, `MedicineInfo[] medicines`, `string message` |
| `/medicart/db/verify_medicine` | `VerifyMedicine` | `string patient_id`, `int32 step_index`, `string scanned_text` | `bool success`, `bool match`, `MedicineInfo expected`, `MedicineInfo scanned`, `string message` |
| `/medicart/db/update_visit_status` | `UpdateVisitStatus` | `string patient_id`, `string room`, `string status`, `string session_id` | `bool success`, `string message` |

### Service (robot6 내부 — MISSION 2 / 통합)

| 이름 | 타입 | 제공자 | 호출자 |
| --- | --- | --- | --- |
| `/robot6/ocr/get_result` | `GetOcrResult` | ocr_node (MISSION 2) | scanner_node |
| `/robot6/scanner/verify_medicine` | `VerifyMedicine` | scanner_node | mission_manager |

### Topic

| 이름 | 타입 | 발행자 | 구독자 |
| --- | --- | --- | --- |
| `/robot3/patient_identified` | `PatientIdentified` | identifier_node (MISSION 5) | mission_manager, dashboard |
| `/robot6/target_pose` | `geometry_msgs/PoseStamped` | tracker_node (MISSION 4) | Nav2 (추종) |
| `/robot3/robot_state`, `/robot6/robot_state` | `RobotState` | 각 mission_manager | dashboard |

### Message 필드 (medi_interfaces에 이미 있음 — 함부로 바꾸지 말 것)

```
PatientIdentified: Header header, string patient_id, string patient_name,
                   string room, bool is_present, bool is_identified, string status
MedicineInfo:      string medicine_id, string name, string dosage,
                   string expiry, string manufacturer, int32 sequence_order
PatientInfo:       string patient_id, string name, string room
TargetBBox:        Header header, float32[4] bbox, float32 confidence,
                   int32 tracking_id, float32 depth, Point spatial_coordinates
```

---

## 0.4 ★ 중요: 오늘 메인브랜치 사고 안 나게 하는 규칙 ★

지난번 main 강제 덮어쓰기 사고가 있었으니, 내일은 아래만 지켜주세요.

1. **각자 자기 feature 브랜치에서만 작업.** main에 직접 push 금지.
2. **PR로만 main에 병합.** force-push(`-f`) 절대 금지.
3. **패키지 단위로 작업이 갈려 있으니, 남의 패키지 파일은 건드리지 않기.** 아래 "충돌 방지 맵" 참고.
4. **공용 영역(아래 ★표시)은 반드시 단톡방 공유 후 수정.** 여기가 충돌 1순위입니다.

### 충돌 방지 맵 (누가 어느 파일을 소유하나)

| 패키지/파일 | 소유 미션 | 비고 |
| --- | --- | --- |
| `patient_identifier/qr_scanner.py` | MISSION 1 | |
| `ocr_detector/*` 전체 | MISSION 2 | |
| `db_bridge/*` 전체 | MISSION 3 | |
| `nurse_tracker/*` (→ `medicine_tracker` 권장) | MISSION 4 | |
| `mission_manager/*` | MISSION 5 | robot6 mission_manager도 여기서 관리 |
| `patient_identifier/identifier_node.py` | MISSION 5 | QR 파트(M1)와 협의 필요 |
| ★ `medi_interfaces/*` (msg/srv) | **공용** | 바꾸면 전원 빌드 깨짐. 반드시 사전 공유 |
| ★ `medi_bringup/launch/*` | **공용** | namespace/parameter 주입. 통합 시 함께 수정 |
| ★ RTDB 스키마 | MISSION 3 주도 | `/prescriptions` 등 추가 시 전원 공유 |

---

## 0.5 공통 선행 작업 (이게 안 되면 다 막힘) — 우선순위 순

문서(05_multi_robot…) 기준으로, **아래 순서대로** 풀어야 가장 안 꼬입니다.

1. **RTDB 스키마 보강** (MISSION 3) — `/prescriptions`, `/patient_rooms` 없으면 QR-DB도 투약도 검증 불가.
2. **`db_node` service server 구현** (MISSION 3) — 나머지 노드가 전부 이걸 호출함. **가장 먼저 떠 있어야 함.**
3. **`/robot6/...` 하드코딩 제거** (통합/M5) — 현재 identifier·mission_manager가 `/robot6`로 박혀 있어 robot3에서 못 씀. launch에서 namespace 주입 + 코드는 상대 이름 사용.
4. 그 다음 각 미션 병렬 진행.

> **현재 코드 실태 (문서 기준):** db_bridge / scanner / ocr_detector / obstacle_detector / nurse_tracker 는 거의 **"시작 로그만 찍는 placeholder"** 상태입니다. 인터페이스(srv/msg) 파일은 대부분 이미 있으니, "srv가 없다"가 아니라 **"server/client 연결과 실제 로직이 비어있다"**가 정확한 표현이에요.

---

## 0.6 내일 권장 작업 순서 (시간대별)

각자 독립적으로 갈 수 있지만, 의존성 때문에 아래를 권합니다.

- **오전 1순위:** MISSION 3가 `db_node`에 `GetPrescription`만이라도 **더미 응답**으로 먼저 띄우기 → 나머지가 호출 테스트 가능.
- **오전 병렬:** M1(QR 파싱), M2(OCR 엔진), M4(YOLO 감지) 는 DB 없이도 각자 단위 테스트 가능 → 먼저 진행.
- **오후:** M5가 robot3 namespace 정리하면서 M1(QR)과 identifier 통합.
- **오후 후반:** M3 실제 RTDB 연결 완료 후, M2+M3로 투약 검증 end-to-end, M4로 추종 붙이기.

---

## 0.7 단위 테스트 팁 (dashboard 없이도 됨)

문서에도 적혀 있듯 **UI 없이 CLI로 기능 테스트가 가능합니다.** 각자 이렇게 확인하세요.

```bash
# service 호출 테스트 (예: 처방 조회)
ros2 service call /medicart/db/get_prescription medi_interfaces/srv/GetPrescription "{patient_id: 'P001'}"

# topic 확인 (예: 식별 결과 / 추종 타겟)
ros2 topic echo /robot3/patient_identified
ros2 topic echo /robot6/target_pose

# topic 수동 발행 (남의 노드 없이 내 구독 테스트)
ros2 topic pub /robot6/target_pose geometry_msgs/PoseStamped "{...}"
```

---

## 0.8 막히면

- 인터페이스 이름/타입이 의심되면 → 이 문서 0.3 확인 → 그래도 애매하면 단톡방.
- 남의 패키지를 꼭 고쳐야 할 것 같으면 → **고치기 전에** 공유. (오늘 사고 재발 방지)
- 제 몫(복구/조율)은 제가 돌아와서 정리할게요. 우선 각자 자기 미션 파일대로 진행 부탁드려요!
