# MISSION 3 — QR ↔ DB 연동 (db_node + RTDB 스키마)

**담당:** (DB 담당자)
**주 패키지:** `db_bridge/` (`db_node.py`, `firebase_client.py`, `models.py`) + Firebase RTDB
**연계:** 거의 모든 미션이 당신을 호출함. **가장 먼저 떠 있어야 하는 노드.**

> 먼저 `00_INTEGRATION_GUIDE.md`를 읽고 오세요. 특히 0.5(공통 선행작업)에서 **이 미션이 1순위**입니다.

---

## 1. 무엇을 만드나 (한 줄)

ROS2 세계와 Firebase RTDB 사이의 **유일한 통역사** `db_node`를 구현합니다. 로봇 노드들은 RTDB URL을 모르고, 오직 당신이 제공하는 ROS service만 호출합니다. + 검증에 필요한 **RTDB 스키마(`/prescriptions` 등)를 보강**합니다.

> 현재 `db_bridge`는 시작 로그만 찍는 placeholder이고, 코드에 `Firestore`라고 잘못 적혀 있습니다. 실제로는 **Firebase Realtime Database(RTDB)**입니다. 모든 표현/구현을 RTDB 기준으로 맞추세요.

RTDB URL:
```
https://medi-cart-ea39f-default-rtdb.asia-southeast1.firebasedatabase.app
```

---

## 2. ★ 먼저 할 일: RTDB 스키마 보강 ★ (이게 없으면 QR-DB도 투약도 안 됨)

현재 RTDB에는 환자정보/방좌표는 있는데, **순서가 있는 처방 목록(`MedicineInfo[]`)을 만들 구조가 없습니다.** 아래를 추가하세요. (05 문서 205~236, 715~755번 줄 기준)

```text
# 1) 처방 (투약 검증 필수)
/prescriptions/{patient_id}/current
  prescription_id: string
  patient_id: string
  room: string
  status: string              # active | completed | cancelled
  updated_ts: number
  medicines/{sequence_order}
    medicine_id: string
    name: string              # ★ M2의 약 라벨 약명과 정확히 일치시킬 것
    dosage: string
    expiry: string
    manufacturer: string
    sequence_order: number
    ocr_keywords: [string]    # OCR 매칭 보조 키워드

# 2) 환자→방 역조회 (QR 검증 안정화)
/patient_rooms/{patient_id}/room

# 3) 순회 결과 기록
/robot_visits/{session_id}/{push_id}
  robot_id, room, patient_id, status, message, ts

# 4) 투약 세션/스캔 로그
/medication_sessions/{session_id}
  robot_id, patient_id, room, status, current_step, total_steps, started_ts, ended_ts
/medicine_scan_logs/{session_id}/{step_index}
  patient_id, expected_medicine_id, expected_name, scanned_text, match, confidence, ts
```

> **시드 데이터:** 테스트용으로 환자 1~2명 + 각 처방 2~3개 약을 미리 넣어두세요. `scripts/seed_rtdb.py` 같은 스크립트로 만들면 재현 쉬움(05 문서 902번 줄). **약명은 M2(OCR)와 반드시 합의.**

---

## 3. 구현해야 할 Service Server (핵심 산출물 3개)

srv 파일은 medi_interfaces에 **이미 존재**합니다. **server 구현과 RTDB 읽기/쓰기 + ROS 메시지 변환**이 빠져있어요.

### 3-1. `/medicart/db/get_prescription` (`GetPrescription`)
- **QR-DB 연동의 핵심.** patient_id를 받아 환자정보 + 처방목록 반환.
- 동작:
  ```
  Request: patient_id
  → RTDB read: /patients/{id}/info/성명  → PatientInfo.name
  → room 조회 (우선순위):
      1) /patients/{id}/room
      2) /patient_rooms/{id}/room
      3) /rooms/*/patient(_id) 역검색
  → RTDB read: /prescriptions/{id}/current/medicines (sequence_order 오름차순)
      → MedicineInfo[] 로 변환
  Response: success, PatientInfo, MedicineInfo[], message
  ```

### 3-2. `/medicart/db/verify_medicine` (`VerifyMedicine`)
- scanner_node가 OCR 텍스트를 들고 "현재 step 약이랑 맞아?"라고 물어봄.
- 동작:
  ```
  Request: patient_id, step_index, scanned_text
  → RTDB read: /prescriptions/{id}/current/medicines/{step_index}
  → expected 약명/키워드 vs scanned_text 매칭 (대소문자/공백 무시, ocr_keywords 활용)
  → (선택) RTDB write: /medicine_scan_logs/{session_id}/{step_index}
  Response: success, match(bool), MedicineInfo expected, MedicineInfo scanned, message
  ```

### 3-3. `/medicart/db/update_visit_status` (`UpdateVisitStatus`)
- robot3가 환자 순회 결과(identified/absent/mismatch/no_qr/db_error)를 기록.
- 동작:
  ```
  Request: patient_id, room, status, session_id
  → RTDB write: /robot_visits/{session_id}/{push_id}
  → RTDB write: /patients/{id}/visits/{push_id}
  Response: success, message
  ```
  > 주의: `UpdateVisitStatus.srv`에는 `robot_id` 필드가 없음(05 문서 675번 줄). robot_id는 session_id 규칙이나 db_node parameter로 정하세요.

### (선택) room pose 조회
- mission_manager가 pharmacy/home/환자방 좌표를 RTDB `/rooms`에서 가져오려면 `ListRooms`/`GetRoomPose` 같은 신규 srv가 필요(05 문서 506·681번 줄). 현재 medi_interfaces에 없음. **당장은 mission_manager가 YAML waypoint를 쓰는 걸로 우회**하고, 시간 남으면 이 srv 추가. ★ 신규 srv는 공용이라 추가 시 단톡방 공유.

---

## 4. 노드 설정 (parameter)

```text
database_url = https://medi-cart-ea39f-default-rtdb.asia-southeast1.firebasedatabase.app
namespace    = /medicart
```

`firebase_client.py`에서 REST 또는 firebase SDK로 RTDB 접근. `db_node.py`에서 3개 service server 등록. `setup.py`/`package.xml`/`README`의 Firestore 표현도 RTDB로 수정.

---

## 5. 데이터 변환 규칙 (RTDB JSON ↔ ROS msg)

| ROS field | RTDB source |
| --- | --- |
| `PatientInfo.patient_id` | request의 patient_id |
| `PatientInfo.name` | `/patients/{id}/info/성명` |
| `PatientInfo.room` | 위 3-1 room 우선순위 |
| `MedicineInfo[]` | `/prescriptions/{id}/current/medicines`, sequence_order 정렬 |

RTDB는 한글 키(`성명` 등)를 쓰고 있으니 파싱 시 주의.

---

## 6. ROS2 통신 요약

| 인터페이스 | 타입 | 방향 | RTDB 동작 |
| --- | --- | --- | --- |
| `/medicart/db/get_prescription` | `GetPrescription` | **server** | read patients/rooms/prescriptions |
| `/medicart/db/verify_medicine` | `VerifyMedicine` | **server** | read prescriptions, write scan_logs(선택) |
| `/medicart/db/update_visit_status` | `UpdateVisitStatus` | **server** | write robot_visits, patients/visits |

호출자: identifier_node(M5/M1), mission_manager(M5), scanner_node(M2 흐름).

---

## 7. 단위 테스트

```bash
# db_node 실행 후 CLI로 직접 호출 (로봇 없이 검증 가능)
ros2 run db_bridge db_node

# 처방 조회
ros2 service call /medicart/db/get_prescription medi_interfaces/srv/GetPrescription "{patient_id: 'P001'}"

# 약 검증
ros2 service call /medicart/db/verify_medicine medi_interfaces/srv/VerifyMedicine \
  "{patient_id: 'P001', step_index: 0, scanned_text: '타이레놀 500mg'}"

# 방문 기록
ros2 service call /medicart/db/update_visit_status medi_interfaces/srv/UpdateVisitStatus \
  "{patient_id: 'P001', room: '101-A', status: 'identified', session_id: 'test1'}"
```

> ★ **오전 팁:** RTDB 연결이 늦어지면, 우선 **하드코딩 더미 응답**으로라도 3개 server를 먼저 띄워주세요. 그래야 M1/M2/M5가 호출 테스트를 시작할 수 있습니다(통합 가이드 0.6).

---

## 8. 완료 기준 (Definition of Done)

- [ ] RTDB `/prescriptions`, `/patient_rooms` 등 스키마 추가 + 시드 데이터
- [ ] `firebase_client.py` 실제 RTDB 연결 (Firestore 표현 제거)
- [ ] 3개 service server 동작 (get_prescription / verify_medicine / update_visit_status)
- [ ] RTDB JSON → PatientInfo / MedicineInfo[] 변환 정확
- [ ] 약명을 M2(OCR)와 일치시킴
- [ ] CLI service call로 전부 검증
- [ ] 본인 브랜치 → PR (main 직접 push 금지)
